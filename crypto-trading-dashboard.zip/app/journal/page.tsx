import { Header } from "@/components/layout/header"
import { TickerTape } from "@/components/dashboard/ticker-tape"
import { StrategyList } from "@/components/journal/strategy-list"
import { TradeJournal } from "@/components/journal/trade-journal"
import { JournalStats } from "@/components/journal/journal-stats"
import { PnLChart } from "@/components/journal/pnl-chart"

export default function JournalPage() {
  return (
    <div className="min-h-screen bg-background">
      <TickerTape />
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">Trading Journal</h1>
          <p className="text-muted-foreground">Track your strategies and trades with detailed analytics</p>
        </div>

        <div className="space-y-6">
          <JournalStats />

          <PnLChart />

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <TradeJournal />
            </div>
            <div>
              <StrategyList />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
