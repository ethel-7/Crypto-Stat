import { Header } from "@/components/layout/header"
import { TickerTape } from "@/components/dashboard/ticker-tape"
import { TechnicalAnalysis } from "@/components/research/technical-analysis"
import { CoinSelector } from "@/components/research/coin-selector"
import { IndicatorCharts } from "@/components/research/indicator-charts"
import { MarketSentiment } from "@/components/research/market-sentiment"

export default function ResearchPage() {
  return (
    <div className="min-h-screen bg-background">
      <TickerTape />
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">Research Hub</h1>
          <p className="text-muted-foreground">Technical analysis and market indicators</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <CoinSelector />
          </div>
          <div className="lg:col-span-3">
            <TechnicalAnalysis />
          </div>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <IndicatorCharts />
          <MarketSentiment />
        </div>
      </main>
    </div>
  )
}
