import { Header } from "@/components/layout/header"
import { TickerTape } from "@/components/dashboard/ticker-tape"
import { MarketOverview } from "@/components/dashboard/market-overview"
import { PriceChart } from "@/components/dashboard/price-chart"
import { CoinList } from "@/components/dashboard/coin-list"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <TickerTape />
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">Market Dashboard</h1>
          <p className="text-muted-foreground">Real-time cryptocurrency market data</p>
        </div>

        <MarketOverview />

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <PriceChart />
          </div>
          <div>
            <CoinList />
          </div>
        </div>
      </main>
    </div>
  )
}
