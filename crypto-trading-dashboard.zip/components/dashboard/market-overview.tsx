"use client"
import { useGlobalData, useTrendingCoins, useTopCoins } from "@/hooks/use-crypto-data"
import { GlassCard } from "@/components/ui/glass-card"
import { AnimatedNumber } from "@/components/ui/animated-number"
import { Globe, Bitcoin, TrendingUp, Flame } from "lucide-react"
import { cn } from "@/lib/utils"

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5 },
  }),
}

export function MarketOverview() {
  const { data: globalData, isLoading: globalLoading } = useGlobalData()
  const { data: trending, isLoading: trendingLoading } = useTrendingCoins()
  const { data: coins, isLoading: coinsLoading } = useTopCoins(20)

  const formatMarketCap = (value: number) => {
    if (value >= 1e12) return `$${(value / 1e12).toFixed(2)}T`
    if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`
    return `$${value.toLocaleString()}`
  }

  // Get top gainers and losers
  const sortedByChange = coins
    ? [...coins].sort((a, b) => b.price_change_percentage_24h - a.price_change_percentage_24h)
    : []
  const topGainers = sortedByChange.slice(0, 3)

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {/* Global Market Cap */}
      <GlassCard custom={0} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-4/20 to-chart-4/5">
            <Globe className="h-5 w-5 text-chart-4" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Global Market Cap</span>
        </div>
        {globalLoading ? (
          <div className="h-8 w-32 animate-pulse rounded bg-secondary" />
        ) : (
          <>
            <AnimatedNumber
              value={globalData?.data.total_market_cap.usd || 0}
              format={formatMarketCap}
              className="text-2xl font-bold text-foreground"
            />
            <p
              className={cn(
                "mt-1 text-sm font-medium",
                (globalData?.data.market_cap_change_percentage_24h_usd || 0) >= 0 ? "text-chart-1" : "text-destructive",
              )}
            >
              {(globalData?.data.market_cap_change_percentage_24h_usd || 0) >= 0 ? "+" : ""}
              {globalData?.data.market_cap_change_percentage_24h_usd.toFixed(2)}% (24h)
            </p>
          </>
        )}
      </GlassCard>

      {/* BTC Dominance */}
      <GlassCard custom={1} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-3/20 to-chart-3/5">
            <Bitcoin className="h-5 w-5 text-chart-3" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">BTC Dominance</span>
        </div>
        {globalLoading ? (
          <div className="h-8 w-24 animate-pulse rounded bg-secondary" />
        ) : (
          <>
            <AnimatedNumber
              value={globalData?.data.market_cap_percentage.btc || 0}
              format={(n) => `${n.toFixed(1)}%`}
              className="text-2xl font-bold text-foreground"
            />
            <p className="mt-1 text-sm text-muted-foreground">
              ETH: {globalData?.data.market_cap_percentage.eth.toFixed(1)}%
            </p>
          </>
        )}
      </GlassCard>

      {/* Top Gainers */}
      <GlassCard custom={2} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-1/20 to-chart-1/5">
            <TrendingUp className="h-5 w-5 text-chart-1" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Top Gainers</span>
        </div>
        {coinsLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-5 animate-pulse rounded bg-secondary" />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {topGainers.map((coin) => (
              <div key={coin.id} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="h-4 w-4 rounded-full" />
                  <span className="text-muted-foreground">{coin.symbol.toUpperCase()}</span>
                </div>
                <span className="font-medium text-chart-1">+{coin.price_change_percentage_24h.toFixed(1)}%</span>
              </div>
            ))}
          </div>
        )}
      </GlassCard>

      {/* Trending */}
      <GlassCard custom={3} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-2/20 to-chart-2/5">
            <Flame className="h-5 w-5 text-chart-2" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Trending</span>
        </div>
        {trendingLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-5 animate-pulse rounded bg-secondary" />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {trending?.slice(0, 3).map((coin, index) => (
              <div key={coin.item.id} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-chart-5">#{index + 1}</span>
                  <img
                    src={coin.item.thumb || "/placeholder.svg"}
                    alt={coin.item.name}
                    className="h-4 w-4 rounded-full"
                  />
                  <span className="text-muted-foreground">{coin.item.symbol}</span>
                </div>
                <span className="text-xs text-muted-foreground">Score: {coin.item.score}</span>
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  )
}
