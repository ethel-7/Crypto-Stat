"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useTopCoins } from "@/hooks/use-crypto-data"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { Input } from "@/components/ui/input"
import { TrendingUp, TrendingDown, Search } from "lucide-react"
import { cn } from "@/lib/utils"

export function CoinList() {
  const [search, setSearch] = useState("")
  const { data: coins, isLoading } = useTopCoins(50)
  const { settings, updateSettings } = useCryptoStore()

  const filteredCoins = coins?.filter(
    (coin) =>
      coin.name.toLowerCase().includes(search.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <GlassCard
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="p-5"
    >
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Markets</h3>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search..."
            className="w-48 border-border/10 bg-secondary/50 pl-9 text-sm text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>

      <div className="max-h-[400px] overflow-y-auto pr-2 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-secondary">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center justify-between rounded-lg bg-secondary/30 p-3">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 animate-pulse rounded-full bg-secondary" />
                  <div className="space-y-1">
                    <div className="h-4 w-20 animate-pulse rounded bg-secondary" />
                    <div className="h-3 w-12 animate-pulse rounded bg-secondary" />
                  </div>
                </div>
                <div className="h-4 w-24 animate-pulse rounded bg-secondary" />
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-1">
            {filteredCoins?.map((coin, index) => (
              <motion.button
                key={coin.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.02 }}
                onClick={() => updateSettings({ selectedCoin: coin.id })}
                className={cn(
                  "flex w-full items-center justify-between rounded-lg p-3 text-left transition-colors",
                  settings.selectedCoin === coin.id ? "bg-secondary" : "hover:bg-secondary/50",
                )}
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 text-xs text-chart-5">{coin.market_cap_rank}</span>
                  <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="h-7 w-7 rounded-full" />
                  <div>
                    <p className="font-medium text-foreground">{coin.symbol.toUpperCase()}</p>
                    <p className="text-xs text-muted-foreground">{coin.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-foreground">
                    $
                    {coin.current_price.toLocaleString(undefined, {
                      maximumFractionDigits: coin.current_price < 1 ? 6 : 2,
                    })}
                  </p>
                  <p
                    className={cn(
                      "flex items-center justify-end gap-1 text-xs font-medium",
                      coin.price_change_percentage_24h >= 0 ? "text-chart-1" : "text-destructive",
                    )}
                  >
                    {coin.price_change_percentage_24h >= 0 ? (
                      <TrendingUp className="h-3 w-3" />
                    ) : (
                      <TrendingDown className="h-3 w-3" />
                    )}
                    {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
                  </p>
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </GlassCard>
  )
}
