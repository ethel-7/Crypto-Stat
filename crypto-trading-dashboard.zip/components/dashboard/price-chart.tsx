"use client"

import { useMemo } from "react"
import { useMarketChart, useTopCoins } from "@/hooks/use-crypto-data"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart, CartesianGrid } from "recharts"
import { TrendingUp, TrendingDown, BarChart2, LineChartIcon } from "lucide-react"
import { cn } from "@/lib/utils"

const timeframes = [
  { value: "1", label: "1D" },
  { value: "7", label: "7D" },
  { value: "30", label: "1M" },
  { value: "90", label: "3M" },
  { value: "365", label: "1Y" },
  { value: "max", label: "ALL" },
]

export function PriceChart() {
  const { settings, updateSettings } = useCryptoStore()
  const { data: coins } = useTopCoins(30)
  const { data: chartData, isLoading } = useMarketChart(settings.selectedCoin, settings.chartTimeframe)

  const selectedCoinData = coins?.find((c) => c.id === settings.selectedCoin)

  const processedData = useMemo(() => {
    if (!chartData?.prices) return []
    return chartData.prices.map(([timestamp, price]) => ({
      timestamp,
      price,
      date: new Date(timestamp).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      }),
    }))
  }, [chartData])

  const priceChange = useMemo(() => {
    if (!processedData.length) return { value: 0, percentage: 0 }
    const first = processedData[0].price
    const last = processedData[processedData.length - 1].price
    return {
      value: last - first,
      percentage: ((last - first) / first) * 100,
    }
  }, [processedData])

  const isPositive = priceChange.percentage >= 0

  return (
    <GlassCard
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="p-6"
      glow
    >
      {/* Header */}
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <Select value={settings.selectedCoin} onValueChange={(value) => updateSettings({ selectedCoin: value })}>
            <SelectTrigger className="w-[180px] border-border/10 bg-secondary/50 text-foreground">
              <SelectValue placeholder="Select coin" />
            </SelectTrigger>
            <SelectContent className="border-border/10 bg-card text-foreground">
              {coins?.map((coin) => (
                <SelectItem key={coin.id} value={coin.id}>
                  <div className="flex items-center gap-2">
                    <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="h-4 w-4 rounded-full" />
                    {coin.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedCoinData && (
            <div>
              <p className="text-2xl font-bold text-foreground">
                $
                {selectedCoinData.current_price.toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
              </p>
              <p
                className={cn(
                  "flex items-center gap-1 text-sm font-medium",
                  isPositive ? "text-chart-1" : "text-destructive",
                )}
              >
                {isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                {isPositive ? "+" : ""}
                {priceChange.percentage.toFixed(2)}%
              </p>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Chart Type Toggle */}
          <div className="flex rounded-lg border border-border/10 bg-secondary/50 p-1">
            <button
              onClick={() => updateSettings({ chartType: "line" })}
              className={cn(
                "flex items-center justify-center rounded-md p-2 transition-colors",
                settings.chartType === "line"
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <LineChartIcon className="h-4 w-4" />
            </button>
            <button
              onClick={() => updateSettings({ chartType: "candlestick" })}
              className={cn(
                "flex items-center justify-center rounded-md p-2 transition-colors",
                settings.chartType === "candlestick"
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <BarChart2 className="h-4 w-4" />
            </button>
          </div>

          {/* Timeframe Selector */}
          <div className="flex rounded-lg border border-border/10 bg-secondary/50 p-1">
            {timeframes.map((tf) => (
              <button
                key={tf.value}
                onClick={() =>
                  updateSettings({
                    chartTimeframe: tf.value as typeof settings.chartTimeframe,
                  })
                }
                className={cn(
                  "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                  settings.chartTimeframe === tf.value
                    ? "bg-secondary text-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {tf.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="h-[350px]">
        {isLoading ? (
          <div className="flex h-full items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={processedData}>
              <defs>
                <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop
                    offset="0%"
                    stopColor={isPositive ? "var(--chart-1)" : "var(--destructive)"}
                    stopOpacity={0.3}
                  />
                  <stop
                    offset="100%"
                    stopColor={isPositive ? "var(--chart-1)" : "var(--destructive)"}
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" strokeOpacity={0.2} vertical={false} />
              <XAxis
                dataKey="date"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                dy={10}
              />
              <YAxis
                domain={["auto", "auto"]}
                axisLine={false}
                tickLine={false}
                tick={{ fill: "var(--muted-foreground)", fontSize: 12 }}
                tickFormatter={(value) =>
                  `$${value.toLocaleString(undefined, {
                    maximumFractionDigits: 0,
                  })}`
                }
                dx={-10}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: "12px",
                  boxShadow: "0 4px 20px var(--shadow-color)",
                }}
                labelStyle={{ color: "var(--muted-foreground)" }}
                formatter={(value: number) => [
                  `$${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`,
                  "Price",
                ]}
              />
              <Area
                type="monotone"
                dataKey="price"
                stroke={isPositive ? "var(--chart-1)" : "var(--destructive)"}
                strokeWidth={2}
                fill="url(#priceGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </GlassCard>
  )
}
