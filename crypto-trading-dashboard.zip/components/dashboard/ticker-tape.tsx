"use client"

import { motion } from "framer-motion"
import { useTopCoins } from "@/hooks/use-crypto-data"
import { TrendingUp, TrendingDown } from "lucide-react"
import { cn } from "@/lib/utils"

export function TickerTape() {
  const { data: coins, isLoading } = useTopCoins(10)

  if (isLoading || !coins) {
    return <div className="h-10 animate-pulse bg-card/50 border-b border-border/5" />
  }

  // Duplicate for seamless loop
  const duplicatedCoins = [...coins, ...coins]

  return (
    <div className="relative overflow-hidden border-b border-border/5 bg-background/80 backdrop-blur-sm">
      <motion.div
        className="flex gap-8 py-2.5 whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{
          x: {
            duration: 30,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear",
          },
        }}
      >
        {duplicatedCoins.map((coin, index) => (
          <div key={`${coin.id}-${index}`} className="flex items-center gap-2 text-sm">
            <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="h-5 w-5 rounded-full" />
            <span className="font-medium text-foreground">{coin.symbol.toUpperCase()}</span>
            <span className="text-muted-foreground">
              ${coin.current_price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </span>
            <span
              className={cn(
                "flex items-center gap-0.5 text-xs font-medium",
                coin.price_change_percentage_24h >= 0 ? "text-chart-1" : "text-destructive",
              )}
            >
              {coin.price_change_percentage_24h >= 0 ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
            </span>
          </div>
        ))}
      </motion.div>
    </div>
  )
}
