"use client"

import { useMemo } from "react"
import { motion } from "framer-motion"
import { useTopCoins, useGlobalData } from "@/hooks/use-crypto-data"
import { GlassCard } from "@/components/ui/glass-card"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"
import { cn } from "@/lib/utils"

export function MarketSentiment() {
  const { data: coins, isLoading: coinsLoading } = useTopCoins(50)
  const { data: globalData, isLoading: globalLoading } = useGlobalData()

  const sentimentData = useMemo(() => {
    if (!coins) return null

    const bullish = coins.filter((c) => c.price_change_percentage_24h > 2).length
    const bearish = coins.filter((c) => c.price_change_percentage_24h < -2).length
    const neutral = coins.length - bullish - bearish

    const avgChange = coins.reduce((sum, c) => sum + c.price_change_percentage_24h, 0) / coins.length

    let overallSentiment: "bullish" | "bearish" | "neutral" = "neutral"
    if (avgChange > 1) overallSentiment = "bullish"
    else if (avgChange < -1) overallSentiment = "bearish"

    return {
      bullish,
      bearish,
      neutral,
      avgChange,
      overallSentiment,
      bullishPercent: (bullish / coins.length) * 100,
      bearishPercent: (bearish / coins.length) * 100,
    }
  }, [coins])

  if (coinsLoading || globalLoading || !sentimentData) {
    return (
      <GlassCard className="p-6">
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      </GlassCard>
    )
  }

  return (
    <GlassCard
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="p-5"
    >
      <h3 className="mb-4 text-lg font-semibold text-foreground">Market Sentiment</h3>

      {/* Overall Sentiment */}
      <div
        className={cn(
          "mb-6 rounded-xl p-4 text-center",
          sentimentData.overallSentiment === "bullish"
            ? "bg-chart-1/20"
            : sentimentData.overallSentiment === "bearish"
              ? "bg-destructive/20"
              : "bg-chart-5/20",
        )}
      >
        <div className="mb-2 flex items-center justify-center gap-2">
          {sentimentData.overallSentiment === "bullish" ? (
            <TrendingUp className="h-6 w-6 text-chart-1" />
          ) : sentimentData.overallSentiment === "bearish" ? (
            <TrendingDown className="h-6 w-6 text-destructive" />
          ) : (
            <Minus className="h-6 w-6 text-muted-foreground" />
          )}
          <span
            className={cn(
              "text-xl font-bold",
              sentimentData.overallSentiment === "bullish"
                ? "text-chart-1"
                : sentimentData.overallSentiment === "bearish"
                  ? "text-destructive"
                  : "text-muted-foreground",
            )}
          >
            {sentimentData.overallSentiment.toUpperCase()}
          </span>
        </div>
        <p className="text-sm text-muted-foreground">
          Average 24h change:{" "}
          <span className={cn(sentimentData.avgChange >= 0 ? "text-chart-1" : "text-destructive")}>
            {sentimentData.avgChange >= 0 ? "+" : ""}
            {sentimentData.avgChange.toFixed(2)}%
          </span>
        </p>
      </div>

      {/* Sentiment Bar */}
      <div className="mb-4">
        <div className="mb-2 flex justify-between text-sm">
          <span className="text-chart-1">Bullish ({sentimentData.bullish})</span>
          <span className="text-muted-foreground">Neutral ({sentimentData.neutral})</span>
          <span className="text-destructive">Bearish ({sentimentData.bearish})</span>
        </div>
        <div className="flex h-3 overflow-hidden rounded-full bg-secondary">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${sentimentData.bullishPercent}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="bg-chart-1"
          />
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${100 - sentimentData.bullishPercent - sentimentData.bearishPercent}%` }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.1 }}
            className="bg-chart-5"
          />
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${sentimentData.bearishPercent}%` }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
            className="bg-destructive"
          />
        </div>
      </div>

      {/* Market Stats */}
      <div className="grid grid-cols-2 gap-4 border-t border-border/5 pt-4">
        <div className="text-center">
          <p className="text-2xl font-bold text-foreground">
            {globalData?.data.active_cryptocurrencies.toLocaleString()}
          </p>
          <p className="text-xs text-muted-foreground">Active Cryptocurrencies</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-foreground">
            ${((globalData?.data.total_volume.usd || 0) / 1e9).toFixed(1)}B
          </p>
          <p className="text-xs text-muted-foreground">24h Volume</p>
        </div>
      </div>

      {/* Top Movers */}
      <div className="mt-4 border-t border-border/5 pt-4">
        <p className="mb-3 text-sm font-medium text-muted-foreground">Top 24h Movers</p>
        <div className="space-y-2">
          {coins
            ?.sort((a, b) => Math.abs(b.price_change_percentage_24h) - Math.abs(a.price_change_percentage_24h))
            .slice(0, 5)
            .map((coin) => (
              <div key={coin.id} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="h-5 w-5 rounded-full" />
                  <span className="text-muted-foreground">{coin.symbol.toUpperCase()}</span>
                </div>
                <span
                  className={cn(
                    "font-medium",
                    coin.price_change_percentage_24h >= 0 ? "text-chart-1" : "text-destructive",
                  )}
                >
                  {coin.price_change_percentage_24h >= 0 ? "+" : ""}
                  {coin.price_change_percentage_24h.toFixed(2)}%
                </span>
              </div>
            ))}
        </div>
      </div>
    </GlassCard>
  )
}
