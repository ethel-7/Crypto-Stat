"use client"

import { useMemo } from "react"
import { motion } from "framer-motion"
import { useMarketChart, useTopCoins, useOHLC } from "@/hooks/use-crypto-data"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { AnimatedNumber } from "@/components/ui/animated-number"
import {
  calculateRSI,
  calculateATR,
  calculateBollingerBands,
  getRSISignal,
  getVolatilityLevel,
} from "@/lib/technical-indicators"
import { TrendingUp, TrendingDown, Activity, Gauge, BarChart3 } from "lucide-react"
import { cn } from "@/lib/utils"

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5 },
  }),
}

export function TechnicalAnalysis() {
  const { settings } = useCryptoStore()
  const { data: coins } = useTopCoins(30)
  const { data: chartData, isLoading } = useMarketChart(settings.selectedCoin, 30)
  const { data: ohlcData } = useOHLC(settings.selectedCoin, 30)

  const selectedCoin = coins?.find((c) => c.id === settings.selectedCoin)

  const indicators = useMemo(() => {
    if (!chartData?.prices || chartData.prices.length < 20) {
      return null
    }

    const prices = chartData.prices.map(([, price]) => price)
    const rsiValues = calculateRSI(prices, 14)
    const currentRSI = rsiValues.filter((v) => !Number.isNaN(v)).pop() || 50

    // Calculate ATR from OHLC data if available
    let currentATR = 0
    let volatilityLevel: "low" | "moderate" | "high" | "extreme" = "moderate"

    if (ohlcData && ohlcData.length > 14) {
      const highs = ohlcData.map((d) => d.high)
      const lows = ohlcData.map((d) => d.low)
      const closes = ohlcData.map((d) => d.close)
      const atrValues = calculateATR(highs, lows, closes, 14)
      currentATR = atrValues.filter((v) => !Number.isNaN(v)).pop() || 0
      volatilityLevel = getVolatilityLevel(currentATR, prices)
    }

    // Calculate Bollinger Bands
    const bb = calculateBollingerBands(prices, 20, 2)
    const currentBB = {
      upper: bb.upper.filter((v) => !Number.isNaN(v)).pop() || 0,
      middle: bb.middle.filter((v) => !Number.isNaN(v)).pop() || 0,
      lower: bb.lower.filter((v) => !Number.isNaN(v)).pop() || 0,
    }

    const currentPrice = prices[prices.length - 1]
    const rsiSignal = getRSISignal(currentRSI)

    // Calculate price position relative to BB
    let bbPosition: "above" | "middle" | "below" = "middle"
    if (currentPrice > currentBB.upper) bbPosition = "above"
    else if (currentPrice < currentBB.lower) bbPosition = "below"

    return {
      rsi: currentRSI,
      rsiSignal,
      atr: currentATR,
      volatilityLevel,
      bollingerBands: currentBB,
      bbPosition,
      currentPrice,
    }
  }, [chartData, ohlcData])

  if (isLoading || !indicators) {
    return (
      <GlassCard className="p-6">
        <div className="flex h-48 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      </GlassCard>
    )
  }

  return (
    <div className="space-y-4">
      {/* Coin Header */}
      {selectedCoin && (
        <GlassCard initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="p-5" glow>
          <div className="flex items-center gap-4">
            <img
              src={selectedCoin.image || "/placeholder.svg"}
              alt={selectedCoin.name}
              className="h-12 w-12 rounded-full"
            />
            <div>
              <h2 className="text-xl font-bold text-foreground">{selectedCoin.name}</h2>
              <p className="text-sm text-muted-foreground">{selectedCoin.symbol.toUpperCase()}</p>
            </div>
            <div className="ml-auto text-right">
              <p className="text-2xl font-bold text-foreground">
                ${selectedCoin.current_price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
              </p>
              <p
                className={cn(
                  "flex items-center justify-end gap-1 text-sm font-medium",
                  selectedCoin.price_change_percentage_24h >= 0 ? "text-chart-1" : "text-destructive",
                )}
              >
                {selectedCoin.price_change_percentage_24h >= 0 ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                {Math.abs(selectedCoin.price_change_percentage_24h).toFixed(2)}% (24h)
              </p>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Technical Indicators */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {/* RSI */}
        <GlassCard custom={0} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
          <div className="mb-3 flex items-center gap-3">
            <div
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br",
                indicators.rsiSignal.signal === "overbought"
                  ? "from-destructive/20 to-destructive/5"
                  : indicators.rsiSignal.signal === "oversold"
                    ? "from-chart-1/20 to-chart-1/5"
                    : "from-chart-5/20 to-chart-5/5",
              )}
            >
              <Gauge
                className={cn(
                  "h-5 w-5",
                  indicators.rsiSignal.signal === "overbought"
                    ? "text-destructive"
                    : indicators.rsiSignal.signal === "oversold"
                      ? "text-chart-1"
                      : "text-muted-foreground",
                )}
              />
            </div>
            <span className="text-sm font-medium text-muted-foreground">RSI (14)</span>
          </div>

          <AnimatedNumber
            value={indicators.rsi}
            format={(n) => n.toFixed(1)}
            className="text-3xl font-bold text-foreground"
          />

          <div className="mt-3">
            <div className="mb-2 h-2 overflow-hidden rounded-full bg-secondary">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${indicators.rsi}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className={cn(
                  "h-full rounded-full",
                  indicators.rsi >= 70 ? "bg-destructive" : indicators.rsi <= 30 ? "bg-chart-1" : "bg-primary",
                )}
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground/70">
              <span>Oversold (30)</span>
              <span>Overbought (70)</span>
            </div>
          </div>

          <div
            className={cn(
              "mt-3 rounded-lg px-3 py-2 text-center text-sm font-medium",
              indicators.rsiSignal.signal === "overbought"
                ? "bg-destructive/20 text-destructive"
                : indicators.rsiSignal.signal === "oversold"
                  ? "bg-chart-1/20 text-chart-1"
                  : "bg-chart-5/20 text-muted-foreground",
            )}
          >
            {indicators.rsiSignal.signal.toUpperCase()} ({indicators.rsiSignal.strength})
          </div>
        </GlassCard>

        {/* Volatility / ATR */}
        <GlassCard custom={1} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
          <div className="mb-3 flex items-center gap-3">
            <div
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br",
                indicators.volatilityLevel === "extreme"
                  ? "from-destructive/20 to-destructive/5"
                  : indicators.volatilityLevel === "high"
                    ? "from-chart-3/20 to-chart-3/5"
                    : "from-primary/20 to-primary/5",
              )}
            >
              <Activity
                className={cn(
                  "h-5 w-5",
                  indicators.volatilityLevel === "extreme"
                    ? "text-destructive"
                    : indicators.volatilityLevel === "high"
                      ? "text-chart-3"
                      : "text-primary",
                )}
              />
            </div>
            <span className="text-sm font-medium text-muted-foreground">Volatility (ATR)</span>
          </div>

          <AnimatedNumber
            value={indicators.atr}
            format={(n) => `$${n.toLocaleString(undefined, { maximumFractionDigits: 2 })}`}
            className="text-3xl font-bold text-foreground"
          />

          <p className="mt-1 text-sm text-muted-foreground">
            {((indicators.atr / indicators.currentPrice) * 100).toFixed(2)}% of price
          </p>

          <div
            className={cn(
              "mt-3 rounded-lg px-3 py-2 text-center text-sm font-medium",
              indicators.volatilityLevel === "extreme"
                ? "bg-destructive/20 text-destructive"
                : indicators.volatilityLevel === "high"
                  ? "bg-chart-3/20 text-chart-3"
                  : indicators.volatilityLevel === "moderate"
                    ? "bg-primary/20 text-primary"
                    : "bg-chart-1/20 text-chart-1",
            )}
          >
            {indicators.volatilityLevel.toUpperCase()} VOLATILITY
          </div>
        </GlassCard>

        {/* Bollinger Bands */}
        <GlassCard custom={2} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
          <div className="mb-3 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-2/20 to-chart-2/5">
              <BarChart3 className="h-5 w-5 text-chart-2" />
            </div>
            <span className="text-sm font-medium text-muted-foreground">Bollinger Bands</span>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Upper</span>
              <span className="font-medium text-destructive">
                ${indicators.bollingerBands.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Middle (SMA)</span>
              <span className="font-medium text-foreground">
                ${indicators.bollingerBands.middle.toLocaleString(undefined, { maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Lower</span>
              <span className="font-medium text-chart-1">
                ${indicators.bollingerBands.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <div
            className={cn(
              "mt-3 rounded-lg px-3 py-2 text-center text-sm font-medium",
              indicators.bbPosition === "above"
                ? "bg-destructive/20 text-destructive"
                : indicators.bbPosition === "below"
                  ? "bg-chart-1/20 text-chart-1"
                  : "bg-chart-5/20 text-muted-foreground",
            )}
          >
            Price {indicators.bbPosition === "above" ? "ABOVE" : indicators.bbPosition === "below" ? "BELOW" : "WITHIN"}{" "}
            bands
          </div>
        </GlassCard>
      </div>
    </div>
  )
}
