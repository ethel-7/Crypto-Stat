"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useTopCoins } from "@/hooks/use-crypto-data"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { Input } from "@/components/ui/input"
import { Search, TrendingUp, TrendingDown } from "lucide-react"
import { cn } from "@/lib/utils"

export function CoinSelector() {
  const [search, setSearch] = useState("")
  const { data: coins, isLoading } = useTopCoins(30)
  const { settings, updateSettings } = useCryptoStore()

  const filteredCoins = coins?.filter(
    (coin) =>
      coin.name.toLowerCase().includes(search.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <GlassCard initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="p-5">
      <h3 className="mb-4 text-lg font-semibold text-foreground">Select Asset</h3>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search coins..."
          className="border-border/10 bg-secondary/50 pl-9 text-sm text-foreground placeholder:text-muted-foreground"
        />
      </div>

      <div className="max-h-[500px] space-y-1 overflow-y-auto pr-1 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-secondary">
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-14 animate-pulse rounded-lg bg-secondary/50" />
            ))}
          </div>
        ) : (
          filteredCoins?.map((coin, index) => (
            <motion.button
              key={coin.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.02 }}
              onClick={() => updateSettings({ selectedCoin: coin.id })}
              className={cn(
                "flex w-full items-center gap-3 rounded-lg p-3 text-left transition-all",
                settings.selectedCoin === coin.id
                  ? "bg-gradient-to-r from-primary/20 to-chart-2/20 ring-1 ring-primary/30"
                  : "hover:bg-secondary/50",
              )}
            >
              <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="h-8 w-8 rounded-full" />
              <div className="flex-1 overflow-hidden">
                <p className="truncate font-medium text-foreground">{coin.name}</p>
                <p className="text-xs text-muted-foreground">{coin.symbol.toUpperCase()}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">
                  ${coin.current_price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </p>
                <p
                  className={cn(
                    "flex items-center justify-end gap-0.5 text-xs font-medium",
                    coin.price_change_percentage_24h >= 0 ? "text-chart-1" : "text-destructive",
                  )}
                >
                  {coin.price_change_percentage_24h >= 0 ? (
                    <TrendingUp className="h-3 w-3" />
                  ) : (
                    <TrendingDown className="h-3 w-3" />
                  )}
                  {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
                </p>
              </div>
            </motion.button>
          ))
        )}
      </div>
    </GlassCard>
  )
}
