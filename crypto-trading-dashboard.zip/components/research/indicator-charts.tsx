"use client"

import { useMemo } from "react"
import { useMarketChart } from "@/hooks/use-crypto-data"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { calculateRSI, calculateBollingerBands } from "@/lib/technical-indicators"
import { XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart, ReferenceLine } from "recharts"

export function IndicatorCharts() {
  const { settings } = useCryptoStore()
  const { data: chartData, isLoading } = useMarketChart(settings.selectedCoin, 30)

  const chartDataProcessed = useMemo(() => {
    if (!chartData?.prices || chartData.prices.length < 20) return null

    const prices = chartData.prices.map(([, price]) => price)
    const timestamps = chartData.prices.map(([timestamp]) => timestamp)
    const rsiValues = calculateRSI(prices, 14)
    const bb = calculateBollingerBands(prices, 20, 2)

    return timestamps.map((timestamp, i) => ({
      date: new Date(timestamp).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      price: prices[i],
      rsi: Number.isNaN(rsiValues[i]) ? null : rsiValues[i],
      bbUpper: Number.isNaN(bb.upper[i]) ? null : bb.upper[i],
      bbMiddle: Number.isNaN(bb.middle[i]) ? null : bb.middle[i],
      bbLower: Number.isNaN(bb.lower[i]) ? null : bb.lower[i],
    }))
  }, [chartData])

  if (isLoading || !chartDataProcessed) {
    return (
      <GlassCard className="p-6">
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      </GlassCard>
    )
  }

  return (
    <GlassCard
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="p-5"
    >
      <h3 className="mb-4 text-lg font-semibold text-foreground">RSI Chart</h3>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartDataProcessed}>
            <defs>
              <linearGradient id="rsiGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="date"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
            />
            <YAxis
              domain={[0, 100]}
              axisLine={false}
              tickLine={false}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
              ticks={[0, 30, 50, 70, 100]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: "8px",
              }}
              labelStyle={{ color: "var(--muted-foreground)" }}
              formatter={(value: number) => [value?.toFixed(2), "RSI"]}
            />
            <ReferenceLine y={70} stroke="var(--destructive)" strokeDasharray="5 5" strokeOpacity={0.5} />
            <ReferenceLine y={30} stroke="var(--chart-1)" strokeDasharray="5 5" strokeOpacity={0.5} />
            <Area type="monotone" dataKey="rsi" stroke="var(--primary)" strokeWidth={2} fill="url(#rsiGradient)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 flex items-center justify-center gap-6 text-xs">
        <div className="flex items-center gap-2">
          <div className="h-0.5 w-4 bg-destructive" style={{ borderStyle: "dashed" }} />
          <span className="text-muted-foreground">Overbought (70)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-0.5 w-4 bg-chart-1" style={{ borderStyle: "dashed" }} />
          <span className="text-muted-foreground">Oversold (30)</span>
        </div>
      </div>
    </GlassCard>
  )
}
