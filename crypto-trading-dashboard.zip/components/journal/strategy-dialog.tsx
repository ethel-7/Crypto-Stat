"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useCryptoStore } from "@/lib/store"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface StrategyDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  editingStrategyId?: string | null
}

export function StrategyDialog({ open, onOpenChange, editingStrategyId }: StrategyDialogProps) {
  const { strategies, addStrategy, updateStrategy } = useCryptoStore()
  const [formData, setFormData] = useState({
    name: "",
    riskRewardTarget: "1:3",
    maxDrawdownLimit: 10,
    entryTriggers: "",
    exitRules: "",
  })

  useEffect(() => {
    if (editingStrategyId) {
      const strategy = strategies.find((s) => s.id === editingStrategyId)
      if (strategy) {
        setFormData({
          name: strategy.name,
          riskRewardTarget: strategy.riskRewardTarget,
          maxDrawdownLimit: strategy.maxDrawdownLimit,
          entryTriggers: strategy.entryTriggers,
          exitRules: strategy.exitRules,
        })
      }
    } else {
      setFormData({
        name: "",
        riskRewardTarget: "1:3",
        maxDrawdownLimit: 10,
        entryTriggers: "",
        exitRules: "",
      })
    }
  }, [editingStrategyId, strategies, open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingStrategyId) {
      updateStrategy(editingStrategyId, formData)
    } else {
      addStrategy(formData)
    }
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border/10 bg-card text-foreground sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{editingStrategyId ? "Edit Strategy" : "Create Trading Strategy"}</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Define your trading plan with clear entry and exit rules
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="text-muted-foreground">
              Strategy Name
            </Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Breakout Trading"
              className="border-border/10 bg-secondary/50 text-foreground"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="riskReward" className="text-muted-foreground">
                Risk:Reward Target
              </Label>
              <Input
                id="riskReward"
                value={formData.riskRewardTarget}
                onChange={(e) => setFormData({ ...formData, riskRewardTarget: e.target.value })}
                placeholder="1:3"
                className="border-border/10 bg-secondary/50 text-foreground"
                required
              />
            </div>

            <div>
              <Label htmlFor="maxDrawdown" className="text-muted-foreground">
                Max Drawdown (%)
              </Label>
              <Input
                id="maxDrawdown"
                type="number"
                value={formData.maxDrawdownLimit}
                onChange={(e) => setFormData({ ...formData, maxDrawdownLimit: Number.parseFloat(e.target.value) })}
                placeholder="10"
                className="border-border/10 bg-secondary/50 text-foreground"
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="entryTriggers" className="text-muted-foreground">
              Entry Triggers
            </Label>
            <Textarea
              id="entryTriggers"
              value={formData.entryTriggers}
              onChange={(e) => setFormData({ ...formData, entryTriggers: e.target.value })}
              placeholder="e.g., RSI < 30, Price breaks above 50 EMA with volume confirmation"
              className="min-h-[80px] border-border/10 bg-secondary/50 text-foreground"
              required
            />
          </div>

          <div>
            <Label htmlFor="exitRules" className="text-muted-foreground">
              Exit Rules
            </Label>
            <Textarea
              id="exitRules"
              value={formData.exitRules}
              onChange={(e) => setFormData({ ...formData, exitRules: e.target.value })}
              placeholder="e.g., Take profit at 1:3 R:R, Stop loss at 2% below entry"
              className="min-h-[80px] border-border/10 bg-secondary/50 text-foreground"
              required
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-border/10">
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-gradient-to-r from-primary to-chart-2 text-primary-foreground hover:from-primary/90 hover:to-chart-2/90"
            >
              {editingStrategyId ? "Update" : "Create"} Strategy
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
