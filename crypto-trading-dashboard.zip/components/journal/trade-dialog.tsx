"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useCryptoStore } from "@/lib/store"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface TradeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  editingTradeId?: string | null
}

export function TradeDialog({ open, onOpenChange, editingTradeId }: TradeDialogProps) {
  const { trades, strategies, addTrade, updateTrade } = useCryptoStore()
  const [formData, setFormData] = useState({
    pair: "",
    direction: "long" as "long" | "short",
    entryPrice: 0,
    exitPrice: null as number | null,
    quantity: 0,
    entryDate: new Date().toISOString().split("T")[0],
    exitDate: null as string | null,
    notes: "",
    status: "open" as "open" | "closed",
    strategyId: "",
  })

  useEffect(() => {
    if (editingTradeId) {
      const trade = trades.find((t) => t.id === editingTradeId)
      if (trade) {
        setFormData({
          pair: trade.pair,
          direction: trade.direction,
          entryPrice: trade.entryPrice,
          exitPrice: trade.exitPrice,
          quantity: trade.quantity,
          entryDate: trade.entryDate.split("T")[0],
          exitDate: trade.exitDate ? trade.exitDate.split("T")[0] : null,
          notes: trade.notes,
          status: trade.status,
          strategyId: trade.strategyId || "",
        })
      }
    } else {
      setFormData({
        pair: "",
        direction: "long",
        entryPrice: 0,
        exitPrice: null,
        quantity: 0,
        entryDate: new Date().toISOString().split("T")[0],
        exitDate: null,
        notes: "",
        status: "open",
        strategyId: "",
      })
    }
  }, [editingTradeId, trades, open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const tradeData = {
      ...formData,
      entryDate: new Date(formData.entryDate).toISOString(),
      exitDate: formData.exitDate ? new Date(formData.exitDate).toISOString() : null,
      strategyId: formData.strategyId || undefined,
    }

    if (editingTradeId) {
      updateTrade(editingTradeId, tradeData)
    } else {
      addTrade(tradeData)
    }
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border/10 bg-card text-foreground sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>{editingTradeId ? "Edit Trade" : "Log New Trade"}</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Record your trade details for performance tracking
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="pair" className="text-muted-foreground">
                Trading Pair
              </Label>
              <Input
                id="pair"
                value={formData.pair}
                onChange={(e) => setFormData({ ...formData, pair: e.target.value })}
                placeholder="BTC/USDT"
                className="border-border/10 bg-secondary/50 text-foreground"
                required
              />
            </div>

            <div>
              <Label htmlFor="direction" className="text-muted-foreground">
                Direction
              </Label>
              <Select
                value={formData.direction}
                onValueChange={(value: "long" | "short") => setFormData({ ...formData, direction: value })}
              >
                <SelectTrigger className="border-border/10 bg-secondary/50 text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-border/10 bg-card text-foreground">
                  <SelectItem value="long">Long</SelectItem>
                  <SelectItem value="short">Short</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="strategy" className="text-muted-foreground">
              Strategy (Optional)
            </Label>
            <Select
              value={formData.strategyId}
              onValueChange={(value) => setFormData({ ...formData, strategyId: value })}
            >
              <SelectTrigger className="border-border/10 bg-secondary/50 text-foreground">
                <SelectValue placeholder="Select strategy" />
              </SelectTrigger>
              <SelectContent className="border-border/10 bg-card text-foreground">
                <SelectItem value="none">None</SelectItem>
                {strategies.map((strategy) => (
                  <SelectItem key={strategy.id} value={strategy.id}>
                    {strategy.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="entryPrice" className="text-muted-foreground">
                Entry Price
              </Label>
              <Input
                id="entryPrice"
                type="number"
                step="0.01"
                value={formData.entryPrice || ""}
                onChange={(e) => setFormData({ ...formData, entryPrice: Number.parseFloat(e.target.value) })}
                placeholder="0.00"
                className="border-border/10 bg-secondary/50 text-foreground"
                required
              />
            </div>

            <div>
              <Label htmlFor="exitPrice" className="text-muted-foreground">
                Exit Price
              </Label>
              <Input
                id="exitPrice"
                type="number"
                step="0.01"
                value={formData.exitPrice || ""}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    exitPrice: e.target.value ? Number.parseFloat(e.target.value) : null,
                    status: e.target.value ? "closed" : "open",
                  })
                }
                placeholder="Leave empty if open"
                className="border-border/10 bg-secondary/50 text-foreground"
              />
            </div>

            <div>
              <Label htmlFor="quantity" className="text-muted-foreground">
                Quantity
              </Label>
              <Input
                id="quantity"
                type="number"
                step="0.001"
                value={formData.quantity || ""}
                onChange={(e) => setFormData({ ...formData, quantity: Number.parseFloat(e.target.value) })}
                placeholder="0.00"
                className="border-border/10 bg-secondary/50 text-foreground"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="entryDate" className="text-muted-foreground">
                Entry Date
              </Label>
              <Input
                id="entryDate"
                type="date"
                value={formData.entryDate}
                onChange={(e) => setFormData({ ...formData, entryDate: e.target.value })}
                className="border-border/10 bg-secondary/50 text-foreground"
                required
              />
            </div>

            <div>
              <Label htmlFor="exitDate" className="text-muted-foreground">
                Exit Date
              </Label>
              <Input
                id="exitDate"
                type="date"
                value={formData.exitDate || ""}
                onChange={(e) => setFormData({ ...formData, exitDate: e.target.value || null })}
                className="border-border/10 bg-secondary/50 text-foreground"
                disabled={!formData.exitPrice}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes" className="text-muted-foreground">
              Notes
            </Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Trade rationale, market conditions, lessons learned..."
              className="min-h-[80px] border-border/10 bg-secondary/50 text-foreground"
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-border/10">
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-gradient-to-r from-primary to-chart-2 text-primary-foreground hover:from-primary/90 hover:to-chart-2/90"
            >
              {editingTradeId ? "Update" : "Log"} Trade
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
