"use client"

import { useMemo } from "react"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts"

export function PnLChart() {
  const { trades } = useCryptoStore()

  const chartData = useMemo(() => {
    const closedTrades = trades
      .filter((t) => t.status === "closed" && t.pnl !== null)
      .sort((a, b) => new Date(a.exitDate!).getTime() - new Date(b.exitDate!).getTime())

    if (closedTrades.length === 0) return []

    let cumulative = 0
    return closedTrades.map((trade) => {
      cumulative += trade.pnl!
      return {
        date: new Date(trade.exitDate!).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
        }),
        pnl: cumulative,
        trade: trade.pair,
      }
    })
  }, [trades])

  if (chartData.length === 0) {
    return (
      <GlassCard className="p-5">
        <h3 className="mb-4 text-lg font-semibold text-foreground">Equity Curve</h3>
        <div className="flex h-48 items-center justify-center text-muted-foreground">
          Close some trades to see your equity curve
        </div>
      </GlassCard>
    )
  }

  const isPositive = chartData[chartData.length - 1]?.pnl >= 0

  return (
    <GlassCard initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-5">
      <h3 className="mb-4 text-lg font-semibold text-foreground">Equity Curve</h3>

      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData}>
            <XAxis
              dataKey="date"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
              tickFormatter={(v) => `$${v}`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: "8px",
              }}
              formatter={(value: number) => [`$${value.toFixed(2)}`, "Cumulative P&L"]}
            />
            <ReferenceLine y={0} stroke="var(--muted-foreground)" strokeDasharray="3 3" />
            <Line
              type="monotone"
              dataKey="pnl"
              stroke={isPositive ? "var(--chart-1)" : "var(--destructive)"}
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  )
}
