"use client"

import { useState } from "react"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { Button } from "@/components/ui/button"
import { Plus, TrendingUp, TrendingDown, Edit2, Trash2, CheckCircle2 } from "lucide-react"
import { TradeDialog } from "./trade-dialog"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

export function TradeJournal() {
  const { trades, deleteTrade, closeTrade } = useCryptoStore()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingTrade, setEditingTrade] = useState<string | null>(null)

  const handleEdit = (id: string) => {
    setEditingTrade(id)
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this trade?")) {
      deleteTrade(id)
    }
  }

  const handleCloseTrade = (id: string) => {
    const exitPrice = prompt("Enter exit price:")
    if (exitPrice && !Number.isNaN(Number.parseFloat(exitPrice))) {
      closeTrade(id, Number.parseFloat(exitPrice), new Date().toISOString())
    }
  }

  // Sort trades by entry date (newest first)
  const sortedTrades = [...trades].sort((a, b) => new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime())

  return (
    <>
      <GlassCard
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="p-5"
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Trade Log</h3>
          <Button
            onClick={() => {
              setEditingTrade(null)
              setDialogOpen(true)
            }}
            className="bg-gradient-to-r from-primary to-chart-2 text-primary-foreground hover:from-primary/90 hover:to-chart-2/90"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Trade
          </Button>
        </div>

        <div className="space-y-3">
          <AnimatePresence>
            {sortedTrades.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="rounded-lg border border-dashed border-border/10 bg-secondary/30 p-12 text-center"
              >
                <TrendingUp className="mx-auto mb-3 h-12 w-12 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">No trades logged yet</p>
                <p className="mt-1 text-xs text-muted-foreground/70">Start tracking your trades to see analytics</p>
              </motion.div>
            ) : (
              sortedTrades.map((trade, index) => (
                <motion.div
                  key={trade.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ delay: index * 0.03 }}
                  className={cn(
                    "group rounded-lg border bg-secondary/30 p-4 transition-all",
                    trade.status === "open"
                      ? "border-primary/20 hover:border-primary/40"
                      : trade.pnl && trade.pnl >= 0
                        ? "border-chart-1/20 hover:border-chart-1/40"
                        : "border-destructive/20 hover:border-destructive/40",
                  )}
                >
                  <div className="mb-3 flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "flex h-10 w-10 items-center justify-center rounded-lg",
                          trade.direction === "long" ? "bg-chart-1/20" : "bg-destructive/20",
                        )}
                      >
                        {trade.direction === "long" ? (
                          <TrendingUp className="h-5 w-5 text-chart-1" />
                        ) : (
                          <TrendingDown className="h-5 w-5 text-destructive" />
                        )}
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">{trade.pair}</h4>
                        <p className="text-xs text-muted-foreground">
                          {trade.direction.toUpperCase()} • {new Date(trade.entryDate).toLocaleDateString()}
                        </p>
                      </div>
                      {trade.status === "open" && (
                        <span className="ml-2 rounded-full bg-primary/20 px-2 py-0.5 text-xs font-medium text-primary">
                          OPEN
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1">
                      {trade.status === "open" && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleCloseTrade(trade.id)}
                          className="h-8 px-2 text-xs text-chart-1 opacity-0 hover:bg-chart-1/20 group-hover:opacity-100"
                        >
                          <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                          Close
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(trade.id)}
                        className="h-7 w-7 p-0 text-muted-foreground opacity-0 hover:bg-secondary hover:text-foreground group-hover:opacity-100"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(trade.id)}
                        className="h-7 w-7 p-0 text-muted-foreground opacity-0 hover:bg-destructive/20 hover:text-destructive group-hover:opacity-100"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm md:grid-cols-4">
                    <div>
                      <span className="text-muted-foreground/70">Entry</span>
                      <p className="font-medium text-foreground">${trade.entryPrice.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground/70">Exit</span>
                      <p className="font-medium text-foreground">
                        {trade.exitPrice ? `$${trade.exitPrice.toLocaleString()}` : "-"}
                      </p>
                    </div>
                    <div>
                      <span className="text-muted-foreground/70">Quantity</span>
                      <p className="font-medium text-foreground">{trade.quantity}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground/70">P&L</span>
                      {trade.pnl !== null ? (
                        <p className={cn("font-bold", trade.pnl >= 0 ? "text-chart-1" : "text-destructive")}>
                          {trade.pnl >= 0 ? "+" : ""}$
                          {trade.pnl.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}{" "}
                          ({trade.pnlPercentage?.toFixed(2)}%)
                        </p>
                      ) : (
                        <p className="text-muted-foreground">-</p>
                      )}
                    </div>
                  </div>

                  {trade.notes && (
                    <div className="mt-3 border-t border-border/5 pt-3">
                      <span className="text-xs text-muted-foreground/70">Notes:</span>
                      <p className="mt-1 text-sm text-muted-foreground">{trade.notes}</p>
                    </div>
                  )}
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </GlassCard>

      <TradeDialog open={dialogOpen} onOpenChange={setDialogOpen} editingTradeId={editingTrade} />
    </>
  )
}
