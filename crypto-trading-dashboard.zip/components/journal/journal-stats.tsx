"use client"

import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { AnimatedNumber } from "@/components/ui/animated-number"
import { TrendingUp, Target, Activity, AlertTriangle } from "lucide-react"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { cn } from "@/lib/utils"

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5 },
  }),
}

export function JournalStats() {
  const { getAnalytics } = useCryptoStore()
  const analytics = getAnalytics()

  const pieData = [
    { name: "Winning", value: analytics.winningTrades, color: "var(--chart-1)" },
    { name: "Losing", value: analytics.losingTrades, color: "var(--destructive)" },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
      {/* Total PnL */}
      <GlassCard custom={0} initial="hidden" animate="visible" variants={cardVariants} className="p-5" glow>
        <div className="mb-3 flex items-center gap-3">
          <div
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br",
              analytics.totalPnl >= 0 ? "from-chart-1/20 to-chart-1/5" : "from-destructive/20 to-destructive/5",
            )}
          >
            <TrendingUp className={cn("h-5 w-5", analytics.totalPnl >= 0 ? "text-chart-1" : "text-destructive")} />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Total P&L</span>
        </div>
        <AnimatedNumber
          value={analytics.totalPnl}
          format={(n) => `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          className={cn("text-2xl font-bold", analytics.totalPnl >= 0 ? "text-chart-1" : "text-destructive")}
        />
        <p className="mt-1 text-sm text-muted-foreground">{analytics.totalTrades} trades</p>
      </GlassCard>

      {/* Win Rate */}
      <GlassCard custom={1} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="mb-3 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-2/20 to-chart-2/5">
            <Target className="h-5 w-5 text-chart-2" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Win Rate</span>
        </div>
        <AnimatedNumber
          value={analytics.winRate}
          format={(n) => `${n.toFixed(1)}%`}
          className="text-2xl font-bold text-foreground"
        />
        <p className="mt-1 text-sm text-muted-foreground">
          {analytics.winningTrades}W / {analytics.losingTrades}L
        </p>
      </GlassCard>

      {/* Profit Factor */}
      <GlassCard custom={2} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="mb-3 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-4/20 to-chart-4/5">
            <Activity className="h-5 w-5 text-chart-4" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Profit Factor</span>
        </div>
        <AnimatedNumber
          value={analytics.profitFactor}
          format={(n) => (Number.isFinite(n) ? n.toFixed(2) : "∞")}
          className="text-2xl font-bold text-foreground"
        />
        <p className="mt-1 text-sm text-muted-foreground">{analytics.profitFactor >= 2 ? "Excellent" : "Good"}</p>
      </GlassCard>

      {/* Avg Risk:Reward */}
      <GlassCard custom={3} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="mb-3 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-chart-3/20 to-chart-3/5">
            <TrendingUp className="h-5 w-5 text-chart-3" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Avg R:R</span>
        </div>
        <AnimatedNumber
          value={analytics.avgRiskReward}
          format={(n) => `1:${n.toFixed(2)}`}
          className="text-2xl font-bold text-foreground"
        />
        <p className="mt-1 text-sm text-muted-foreground">Risk to Reward</p>
      </GlassCard>

      {/* Win Rate Pie Chart */}
      <GlassCard custom={4} initial="hidden" animate="visible" variants={cardVariants} className="p-5">
        <div className="mb-3 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-destructive/20 to-destructive/5">
            <AlertTriangle className="h-5 w-5 text-destructive" />
          </div>
          <span className="text-sm font-medium text-muted-foreground">Distribution</span>
        </div>
        {analytics.totalTrades > 0 ? (
          <ResponsiveContainer width="100%" height={80}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={20} outerRadius={35} paddingAngle={5} dataKey="value">
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <p className="mt-4 text-center text-sm text-muted-foreground">No trades yet</p>
        )}
      </GlassCard>
    </div>
  )
}
