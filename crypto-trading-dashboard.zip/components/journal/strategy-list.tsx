"use client"

import { useState } from "react"
import { useCryptoStore } from "@/lib/store"
import { GlassCard } from "@/components/ui/glass-card"
import { Button } from "@/components/ui/button"
import { Plus, Edit2, Trash2, Target } from "lucide-react"
import { StrategyDialog } from "./strategy-dialog"
import { motion, AnimatePresence } from "framer-motion"

export function StrategyList() {
  const { strategies, deleteStrategy } = useCryptoStore()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingStrategy, setEditingStrategy] = useState<string | null>(null)

  const handleEdit = (id: string) => {
    setEditingStrategy(id)
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this strategy?")) {
      deleteStrategy(id)
    }
  }

  return (
    <>
      <GlassCard
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="p-5"
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Trading Strategies</h3>
          <Button
            size="sm"
            onClick={() => {
              setEditingStrategy(null)
              setDialogOpen(true)
            }}
            className="bg-gradient-to-r from-primary to-chart-2 text-primary-foreground hover:from-primary/90 hover:to-chart-2/90"
          >
            <Plus className="mr-1 h-4 w-4" />
            Add
          </Button>
        </div>

        <div className="space-y-3">
          <AnimatePresence>
            {strategies.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="rounded-lg border border-dashed border-border/10 bg-secondary/30 p-8 text-center"
              >
                <Target className="mx-auto mb-2 h-10 w-10 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">No strategies yet</p>
                <p className="mt-1 text-xs text-muted-foreground/70">Create your first trading strategy</p>
              </motion.div>
            ) : (
              strategies.map((strategy, index) => (
                <motion.div
                  key={strategy.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.05 }}
                  className="group rounded-lg border border-border/5 bg-secondary/30 p-4 transition-all hover:border-border/10 hover:bg-secondary/50"
                >
                  <div className="mb-2 flex items-start justify-between">
                    <h4 className="font-semibold text-foreground">{strategy.name}</h4>
                    <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(strategy.id)}
                        className="h-7 w-7 p-0 text-muted-foreground hover:bg-secondary hover:text-foreground"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(strategy.id)}
                        className="h-7 w-7 p-0 text-muted-foreground hover:bg-destructive/20 hover:text-destructive"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Risk:Reward Target</span>
                      <span className="font-medium text-chart-1">{strategy.riskRewardTarget}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Max Drawdown</span>
                      <span className="font-medium text-destructive">{strategy.maxDrawdownLimit}%</span>
                    </div>
                  </div>

                  <div className="mt-3 space-y-2 border-t border-border/5 pt-3 text-xs">
                    <div>
                      <span className="text-muted-foreground/70">Entry:</span>
                      <p className="mt-0.5 text-muted-foreground">{strategy.entryTriggers}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground/70">Exit:</span>
                      <p className="mt-0.5 text-muted-foreground">{strategy.exitRules}</p>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </GlassCard>

      <StrategyDialog open={dialogOpen} onOpenChange={setDialogOpen} editingStrategyId={editingStrategy} />
    </>
  )
}
