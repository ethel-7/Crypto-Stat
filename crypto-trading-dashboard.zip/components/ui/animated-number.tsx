"use client"

import { useEffect, useRef, useState } from "react"
import { motion, useSpring, useTransform } from "framer-motion"

interface AnimatedNumberProps {
  value: number
  format?: (n: number) => string
  className?: string
  duration?: number
}

export function AnimatedNumber({
  value,
  format = (n) => n.toLocaleString(),
  className,
  duration = 0.8,
}: AnimatedNumberProps) {
  const [displayValue, setDisplayValue] = useState(value)
  const prevValue = useRef(value)

  const spring = useSpring(prevValue.current, {
    stiffness: 100,
    damping: 30,
    duration: duration * 1000,
  })

  const display = useTransform(spring, (latest) => format(latest))

  useEffect(() => {
    prevValue.current = value
    spring.set(value)
  }, [value, spring])

  useEffect(() => {
    return display.on("change", (latest) => {
      setDisplayValue(Number.parseFloat(latest.replace(/[^0-9.-]/g, "")) || 0)
    })
  }, [display])

  return <motion.span className={className}>{format(displayValue)}</motion.span>
}
