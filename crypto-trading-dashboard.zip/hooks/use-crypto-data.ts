"use client"

import useSWR from "swr"
import {
  fetchTopCoins,
  fetchGlobalData,
  fetchTrendingCoins,
  fetchMarketChart,
  fetchOHLC,
  fetchSimplePrices,
  type CoinPrice,
  type GlobalData,
  type TrendingCoin,
  type MarketChartData,
  type OHLCData,
} from "@/lib/coingecko-api"

// SWR configuration for crypto data
const swrConfig = {
  revalidateOnFocus: false,
  dedupingInterval: 30000, // 30 seconds deduplication
}

// Hook for top coins
export function useTopCoins(limit = 50, page = 1) {
  return useSWR<CoinPrice[]>(["topCoins", limit, page], () => fetchTopCoins(limit, page), {
    ...swrConfig,
    refreshInterval: 60000, // Refresh every 60 seconds
  })
}

// Hook for global market data
export function useGlobalData() {
  return useSWR<GlobalData>("globalData", fetchGlobalData, {
    ...swrConfig,
    refreshInterval: 120000, // Refresh every 2 minutes
  })
}

// Hook for trending coins
export function useTrendingCoins() {
  return useSWR<TrendingCoin[]>("trending", fetchTrendingCoins, {
    ...swrConfig,
    refreshInterval: 300000, // Refresh every 5 minutes
  })
}

// Hook for market chart data
export function useMarketChart(coinId: string | null, days: number | string = 7) {
  return useSWR<MarketChartData>(
    coinId ? ["marketChart", coinId, days] : null,
    () => fetchMarketChart(coinId!, days),
    swrConfig,
  )
}

// Hook for OHLC candlestick data
export function useOHLC(coinId: string | null, days = 7) {
  return useSWR<OHLCData[]>(coinId ? ["ohlc", coinId, days] : null, () => fetchOHLC(coinId!, days), swrConfig)
}

// Hook for simple prices
export function useSimplePrices(coinIds: string[]) {
  return useSWR<Record<string, { usd: number; usd_24h_change: number }>>(
    coinIds.length > 0 ? ["simplePrices", coinIds.join(",")] : null,
    () => fetchSimplePrices(coinIds),
    {
      ...swrConfig,
      refreshInterval: 30000, // Refresh every 30 seconds
    },
  )
}
