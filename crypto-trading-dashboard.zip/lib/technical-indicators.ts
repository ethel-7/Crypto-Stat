// Technical Indicator Calculations

// Calculate Simple Moving Average
export function calculateSMA(data: number[], period: number): number[] {
  const result: number[] = []
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(Number.NaN)
    } else {
      const slice = data.slice(i - period + 1, i + 1)
      const sum = slice.reduce((a, b) => a + b, 0)
      result.push(sum / period)
    }
  }
  return result
}

// Calculate Exponential Moving Average
export function calculateEMA(data: number[], period: number): number[] {
  const result: number[] = []
  const multiplier = 2 / (period + 1)

  // First EMA is SMA
  let sum = 0
  for (let i = 0; i < period; i++) {
    sum += data[i]
    result.push(Number.NaN)
  }
  result[period - 1] = sum / period

  // Calculate EMA for remaining data
  for (let i = period; i < data.length; i++) {
    const ema = (data[i] - result[i - 1]) * multiplier + result[i - 1]
    result.push(ema)
  }

  return result
}

// Calculate RSI (Relative Strength Index)
export function calculateRSI(prices: number[], period = 14): number[] {
  const changes: number[] = []
  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1])
  }

  const gains: number[] = []
  const losses: number[] = []

  for (const change of changes) {
    gains.push(change > 0 ? change : 0)
    losses.push(change < 0 ? Math.abs(change) : 0)
  }

  const result: number[] = [Number.NaN] // First value has no change

  // Calculate first average gain/loss
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period

  for (let i = 0; i < period; i++) {
    result.push(Number.NaN)
  }

  // Calculate RSI
  for (let i = period; i < changes.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period

    if (avgLoss === 0) {
      result.push(100)
    } else {
      const rs = avgGain / avgLoss
      result.push(100 - 100 / (1 + rs))
    }
  }

  return result
}

// Calculate ATR (Average True Range) for Volatility
export function calculateATR(highs: number[], lows: number[], closes: number[], period = 14): number[] {
  const trueRanges: number[] = []

  for (let i = 0; i < highs.length; i++) {
    if (i === 0) {
      trueRanges.push(highs[i] - lows[i])
    } else {
      const tr = Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]))
      trueRanges.push(tr)
    }
  }

  return calculateSMA(trueRanges, period)
}

// Calculate Bollinger Bands
export function calculateBollingerBands(
  data: number[],
  period = 20,
  stdDev = 2,
): { upper: number[]; middle: number[]; lower: number[] } {
  const middle = calculateSMA(data, period)
  const upper: number[] = []
  const lower: number[] = []

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      upper.push(Number.NaN)
      lower.push(Number.NaN)
    } else {
      const slice = data.slice(i - period + 1, i + 1)
      const mean = middle[i]
      const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period
      const std = Math.sqrt(variance)
      upper.push(mean + stdDev * std)
      lower.push(mean - stdDev * std)
    }
  }

  return { upper, middle, lower }
}

// Get RSI signal
export function getRSISignal(rsi: number): {
  signal: "overbought" | "oversold" | "neutral"
  strength: "strong" | "moderate" | "weak"
} {
  if (rsi >= 80) return { signal: "overbought", strength: "strong" }
  if (rsi >= 70) return { signal: "overbought", strength: "moderate" }
  if (rsi >= 60) return { signal: "overbought", strength: "weak" }
  if (rsi <= 20) return { signal: "oversold", strength: "strong" }
  if (rsi <= 30) return { signal: "oversold", strength: "moderate" }
  if (rsi <= 40) return { signal: "oversold", strength: "weak" }
  return { signal: "neutral", strength: "weak" }
}

// Calculate volatility percentile
export function getVolatilityLevel(currentATR: number, priceData: number[]): "low" | "moderate" | "high" | "extreme" {
  const avgPrice = priceData.reduce((a, b) => a + b, 0) / priceData.length
  const atrPercentage = (currentATR / avgPrice) * 100

  if (atrPercentage < 2) return "low"
  if (atrPercentage < 4) return "moderate"
  if (atrPercentage < 8) return "high"
  return "extreme"
}
