"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

// Trading Strategy Types
export interface TradingStrategy {
  id: string
  name: string
  riskRewardTarget: string
  maxDrawdownLimit: number
  entryTriggers: string
  exitRules: string
  createdAt: string
  updatedAt: string
}

// Trade Log Types
export interface Trade {
  id: string
  strategyId?: string
  pair: string
  direction: "long" | "short"
  entryPrice: number
  exitPrice: number | null
  quantity: number
  entryDate: string
  exitDate: string | null
  notes: string
  pnl: number | null
  pnlPercentage: number | null
  status: "open" | "closed"
}

// App Settings
export interface AppSettings {
  selectedCoin: string
  chartTimeframe: "1" | "7" | "30" | "90" | "365" | "max"
  chartType: "line" | "candlestick"
  currency: string
}

// Store State
interface CryptoStore {
  // Settings
  settings: AppSettings
  updateSettings: (settings: Partial<AppSettings>) => void

  // Trading Strategies
  strategies: TradingStrategy[]
  addStrategy: (strategy: Omit<TradingStrategy, "id" | "createdAt" | "updatedAt">) => void
  updateStrategy: (id: string, strategy: Partial<TradingStrategy>) => void
  deleteStrategy: (id: string) => void

  // Trade Journal
  trades: Trade[]
  addTrade: (trade: Omit<Trade, "id" | "pnl" | "pnlPercentage">) => void
  updateTrade: (id: string, trade: Partial<Trade>) => void
  closeTrade: (id: string, exitPrice: number, exitDate: string) => void
  deleteTrade: (id: string) => void

  // Computed Analytics
  getAnalytics: () => {
    totalTrades: number
    winRate: number
    profitFactor: number
    avgRiskReward: number
    totalPnl: number
    maxDrawdown: number
    winningTrades: number
    losingTrades: number
  }
}

export const useCryptoStore = create<CryptoStore>()(
  persist(
    (set, get) => ({
      // Default Settings
      settings: {
        selectedCoin: "bitcoin",
        chartTimeframe: "7",
        chartType: "line",
        currency: "usd",
      },

      updateSettings: (newSettings) =>
        set((state) => ({
          settings: { ...state.settings, ...newSettings },
        })),

      // Strategies
      strategies: [],

      addStrategy: (strategy) =>
        set((state) => ({
          strategies: [
            ...state.strategies,
            {
              ...strategy,
              id: crypto.randomUUID(),
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
          ],
        })),

      updateStrategy: (id, updates) =>
        set((state) => ({
          strategies: state.strategies.map((s) =>
            s.id === id ? { ...s, ...updates, updatedAt: new Date().toISOString() } : s,
          ),
        })),

      deleteStrategy: (id) =>
        set((state) => ({
          strategies: state.strategies.filter((s) => s.id !== id),
        })),

      // Trades
      trades: [],

      addTrade: (trade) => {
        const pnl =
          trade.status === "closed" && trade.exitPrice !== null
            ? trade.direction === "long"
              ? (trade.exitPrice - trade.entryPrice) * trade.quantity
              : (trade.entryPrice - trade.exitPrice) * trade.quantity
            : null

        const pnlPercentage =
          pnl !== null
            ? trade.direction === "long"
              ? ((trade.exitPrice! - trade.entryPrice) / trade.entryPrice) * 100
              : ((trade.entryPrice - trade.exitPrice!) / trade.entryPrice) * 100
            : null

        set((state) => ({
          trades: [
            ...state.trades,
            {
              ...trade,
              id: crypto.randomUUID(),
              pnl,
              pnlPercentage,
            },
          ],
        }))
      },

      updateTrade: (id, updates) =>
        set((state) => ({
          trades: state.trades.map((t) => (t.id === id ? { ...t, ...updates } : t)),
        })),

      closeTrade: (id, exitPrice, exitDate) =>
        set((state) => ({
          trades: state.trades.map((t) => {
            if (t.id !== id) return t

            const pnl =
              t.direction === "long" ? (exitPrice - t.entryPrice) * t.quantity : (t.entryPrice - exitPrice) * t.quantity

            const pnlPercentage =
              t.direction === "long"
                ? ((exitPrice - t.entryPrice) / t.entryPrice) * 100
                : ((t.entryPrice - exitPrice) / t.entryPrice) * 100

            return {
              ...t,
              exitPrice,
              exitDate,
              status: "closed" as const,
              pnl,
              pnlPercentage,
            }
          }),
        })),

      deleteTrade: (id) =>
        set((state) => ({
          trades: state.trades.filter((t) => t.id !== id),
        })),

      // Analytics Calculator
      getAnalytics: () => {
        const { trades } = get()
        const closedTrades = trades.filter((t) => t.status === "closed" && t.pnl !== null)

        if (closedTrades.length === 0) {
          return {
            totalTrades: 0,
            winRate: 0,
            profitFactor: 0,
            avgRiskReward: 0,
            totalPnl: 0,
            maxDrawdown: 0,
            winningTrades: 0,
            losingTrades: 0,
          }
        }

        const winningTrades = closedTrades.filter((t) => t.pnl! > 0)
        const losingTrades = closedTrades.filter((t) => t.pnl! < 0)

        const totalPnl = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0)
        const grossProfit = winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0)
        const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0))

        const winRate = (winningTrades.length / closedTrades.length) * 100
        const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Number.POSITIVE_INFINITY : 0

        // Calculate average risk:reward
        const avgWin =
          winningTrades.length > 0
            ? winningTrades.reduce((sum, t) => sum + Math.abs(t.pnlPercentage || 0), 0) / winningTrades.length
            : 0
        const avgLoss =
          losingTrades.length > 0
            ? losingTrades.reduce((sum, t) => sum + Math.abs(t.pnlPercentage || 0), 0) / losingTrades.length
            : 0
        const avgRiskReward = avgLoss > 0 ? avgWin / avgLoss : 0

        // Calculate max drawdown
        let peak = 0
        let maxDrawdown = 0
        let runningPnl = 0
        closedTrades
          .sort((a, b) => new Date(a.exitDate!).getTime() - new Date(b.exitDate!).getTime())
          .forEach((trade) => {
            runningPnl += trade.pnl || 0
            if (runningPnl > peak) peak = runningPnl
            const drawdown = peak - runningPnl
            if (drawdown > maxDrawdown) maxDrawdown = drawdown
          })

        return {
          totalTrades: closedTrades.length,
          winRate,
          profitFactor,
          avgRiskReward,
          totalPnl,
          maxDrawdown,
          winningTrades: winningTrades.length,
          losingTrades: losingTrades.length,
        }
      },
    }),
    {
      name: "crypto-journal-storage",
    },
  ),
)
